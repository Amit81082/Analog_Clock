let lastSecondDeg = 0; // 🌟 Second hand ke liye global angle store

function updateClock() {
    const now = new Date();
    const hours = now.getHours() % 12;
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    const milliseconds = now.getMilliseconds();

    // ✅ Continuous, Real-time Rotation Calculation
    const hourDeg = (hours * 30) + (minutes * 0.5); // (360° / 12 = 30° per hour, +0.5° per min)
    const minuteDeg = (minutes * 6) + (seconds * 0.1); // (360° / 60 = 6° per min, +0.1° per sec)
    
    // 🌟 Second hand ko smoothly rotate karne ke liye milliseconds bhi add karein
    let secondDeg = (seconds * 6) + (milliseconds * 0.006);

    // ✅ Fix the sudden Jerk issue
    if (secondDeg < lastSecondDeg) {
        lastSecondDeg += 360; // Jab second hand 12 par aayegi, to instead of reset, hum 360 aur add karenge
    }
    lastSecondDeg = secondDeg;

    // ✅ Apply Smooth Rotation
    document.getElementById('hour-hand').style.transform = `rotate(${hourDeg}deg)`;
    document.getElementById('minute-hand').style.transform = `rotate(${minuteDeg}deg)`;
    document.getElementById('second-hand').style.transform = `rotate(${lastSecondDeg}deg)`;

    requestAnimationFrame(updateClock); // Super smooth update 🚀
}

updateClock(); // Start Clock

function createTicks() {
    const tickContainer = document.getElementById("ticks");

    for (let i = 0; i < 12; i++) {
        const tick = document.createElement("div");
        tick.classList.add("tick");

        // ✅ 360° ko 12 parts me divide karke har tick ka angle nikal rahe hain
        const angle = (i * 30); 
        tick.style.transform = `rotate(${angle}deg) translateY(-90px)`; // ✅ Adjust tick position

        tickContainer.appendChild(tick);
    }
}

createTicks(); // ⏳ Ticks Generate karo!

